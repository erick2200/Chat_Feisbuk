package com.erick.chat.activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.erick.chat.R;
import com.erick.chat.entities.Usuario;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegistroActivity extends AppCompatActivity {

    EditText r_nombre,r_correo,r_password1,r_password2;
    Button bt_cancelar,bt_registrar;

    private FirebaseAuth mAuth;

    private FirebaseDatabase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        r_nombre = (EditText) findViewById(R.id.registroNombre);
        r_correo = (EditText) findViewById(R.id.registroCorreo);
        r_password1 = (EditText) findViewById(R.id.registroPassword1);
        r_password2 = (EditText) findViewById(R.id.registroPassword2);

        bt_cancelar = (Button) findViewById(R.id.bt_registroCancelar);
        bt_registrar = (Button) findViewById(R.id.bt_registroRegistro);

        mAuth = FirebaseAuth.getInstance();

        database = FirebaseDatabase.getInstance();


        bt_cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(RegistroActivity.this, LoginActivity.class));
                finish();

            }
        });

        bt_registrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = r_nombre.getText().toString();
                String correo = r_correo.getText().toString();
                String password1 = r_password1.getText().toString();
                String password2 = r_password2.getText().toString();

                if(nombre.isEmpty() || correo.isEmpty() || password1.isEmpty() || password2.isEmpty())
                {
                    Toast.makeText(RegistroActivity.this, "Debe de rellenar todos lo campos", Toast.LENGTH_SHORT).show();
                }
                else if(!(password1.equals(password2)))
                {
                    Toast.makeText(RegistroActivity.this, "Las passwords no conciden", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    mAuth.createUserWithEmailAndPassword(correo, password1)
                            .addOnCompleteListener(RegistroActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(RegistroActivity.this, "Registro exitoso", Toast.LENGTH_SHORT).show();

                                        FirebaseUser currentUser = mAuth.getCurrentUser();


                                        String v_nombre = r_nombre.getText().toString();
                                        String v_correo = r_correo.getText().toString();
                                        String v_foto = "";

                                        Usuario usuario = new Usuario(v_correo,v_nombre);
                                        usuario.setFotoPerfil(v_foto);
                                        DatabaseReference reference = database.getReference("Usuarios/" + currentUser.getUid() );
                                        reference.setValue(usuario);
                                        startActivity(new Intent(RegistroActivity.this,LoginActivity.class));
                                        finish();

                                    } else {
                                        Toast.makeText(RegistroActivity.this, "Error al registrar", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });
    }
}
