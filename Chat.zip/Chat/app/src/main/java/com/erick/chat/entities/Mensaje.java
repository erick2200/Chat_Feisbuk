package com.erick.chat.entities;

public class Mensaje {

    private String texto;
    private String urlFoto;
    private String nombre;
    private String fotoMensaje;
    private String tipo;

    public Mensaje() {
    }

    public Mensaje(String texto,  String nombre, String fotoMensaje, String tipo) {
        this.texto = texto;
        this.nombre = nombre;
        this.fotoMensaje = fotoMensaje;
        this.tipo = tipo;
    }

    public String getUrlFoto() {
        return urlFoto;
    }

    public void setUrlFoto(String urlFoto) {
        this.urlFoto = urlFoto;
    }

    public Mensaje(String texto, String urlFoto, String nombre, String fotoMensaje, String tipo) {
        this.texto = texto;
        this.urlFoto = urlFoto;
        this.nombre = nombre;
        this.fotoMensaje = fotoMensaje;
        this.tipo = tipo;
    }

    public String getTexto() {
        return texto;
    }

    public void setTexto(String texto) {
        this.texto = texto;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFotoMensaje() {
        return fotoMensaje;
    }

    public void setFotoMensaje(String fotoMensaje) {
        this.fotoMensaje = fotoMensaje;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
