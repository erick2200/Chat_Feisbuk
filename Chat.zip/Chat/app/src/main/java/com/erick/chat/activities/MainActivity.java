package com.erick.chat.activities;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.erick.chat.AdapterMensajes;
import com.erick.chat.R;
import com.erick.chat.entities.Mensaje;
import com.erick.chat.entities.MensajeEnviar;
import com.erick.chat.entities.MensajeRecibir;
import com.erick.chat.entities.Usuario;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import de.hdodenhof.circleimageview.CircleImageView;

public class MainActivity extends AppCompatActivity {

    CircleImageView fotoPerfil;
    TextView nombrePerfil;
    RecyclerView contenMensajes;
    EditText mensajeEnviar;
    Button botonEnviar;
    Button botonCerrarSesion;
    ImageButton botonImagen;

    String nombreUsuario;

    private AdapterMensajes adapter;

    private FirebaseDatabase baseDatos;
    private DatabaseReference referenciaBasedatos;

    private FirebaseStorage storage;
    private StorageReference storageReference;

    private Uri mImageUri;

    private static final int IMAGE_SEND = 1;
    private static final int IMAGE_PERFIL = 2;

    private String fotoPerfilString ;

    private FirebaseAuth mAuth;

    String correoUser;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fotoPerfil = (CircleImageView) findViewById(R.id.fotoPerfil);
        nombrePerfil = (TextView) findViewById(R.id.nombrePerfil);
        contenMensajes = (RecyclerView) findViewById(R.id.contenMensajes);
        mensajeEnviar = (EditText) findViewById(R.id.mensajeEnviar);
        botonEnviar = (Button) findViewById(R.id.botonEnviar);
        botonImagen = (ImageButton) findViewById(R.id.botonImagen);
        botonCerrarSesion = (Button) findViewById(R.id.bt_cerrarSesion);
        fotoPerfilString = "";


        baseDatos = FirebaseDatabase.getInstance();
        referenciaBasedatos = baseDatos.getReference("chat");

        storage = FirebaseStorage.getInstance();
        mAuth = FirebaseAuth.getInstance();

        adapter = new AdapterMensajes(this);
        LinearLayoutManager manager = new LinearLayoutManager(this);

        contenMensajes.setLayoutManager(manager);
        contenMensajes.setAdapter(adapter);

        botonEnviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mensaje = mensajeEnviar.getText().toString();
                String nombre = nombrePerfil.getText().toString();

                Mensaje temp = new MensajeEnviar(mensaje,nombre,fotoPerfilString,"1",ServerValue.TIMESTAMP);

                referenciaBasedatos.push().setValue(temp);
                mensajeEnviar.setText("");
            }
        });

        botonCerrarSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
                finish();
            }
        });

        fotoPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/jpeg");
                i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
                startActivityForResult(Intent.createChooser(i,"Selecciona foto"),IMAGE_PERFIL);
            }
        });

        botonImagen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.setType("image/jpeg");
                i.putExtra(Intent.EXTRA_LOCAL_ONLY,true);
                startActivityForResult(Intent.createChooser(i,"Selecciona foto"),IMAGE_SEND);
            }
        });


        adapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onItemRangeInserted(int positionStart, int itemCount) {
                super.onItemRangeInserted(positionStart, itemCount);
                setScroll();
            }
        });


        referenciaBasedatos.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                MensajeRecibir mensaje = dataSnapshot.getValue(MensajeRecibir.class);
                adapter.addMensaje(mensaje);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        verifyStoragePermissions(this);

    }


    private void setScroll()
    {
        contenMensajes.scrollToPosition(adapter.getItemCount()-1);
    }

    @Override
    protected void onActivityResult(final int requestCode, int resultCode, @Nullable final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == IMAGE_SEND && resultCode == RESULT_OK)
        {
            mImageUri = data.getData();
            storageReference = storage.getReference("ChatImage");
            final StorageReference fotoReferencia = storageReference.child(mImageUri.getLastPathSegment());
            fotoReferencia.putFile(mImageUri).addOnSuccessListener(this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    fotoReferencia.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            MensajeEnviar m =  new MensajeEnviar( nombreUsuario +" te envio una foto",uri.toString(),nombreUsuario,fotoPerfilString,"2",ServerValue.TIMESTAMP);
                            referenciaBasedatos.push().setValue(m);
                        }
                    });

                }
            });

        }else if (requestCode == IMAGE_PERFIL && resultCode == RESULT_OK)
        {
            final FirebaseUser v_currentUser = mAuth.getCurrentUser();
            mImageUri = data.getData();
            storageReference = storage.getReference("PerfilImage");
            final StorageReference fotoReferencia = storageReference.child(mImageUri.getLastPathSegment());
            fotoReferencia.putFile(mImageUri).addOnSuccessListener(this, new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    fotoReferencia.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            fotoPerfilString = uri.toString();
                            MensajeEnviar m =  new MensajeEnviar(nombreUsuario +" actualizo su foto de perfil",uri.toString(),nombreUsuario,fotoPerfilString,"2", ServerValue.TIMESTAMP);
                            referenciaBasedatos.push().setValue(m);
                            Glide.with(MainActivity.this).load(uri.toString()).into(fotoPerfil);

                            Usuario v_usuario = new Usuario();
                            v_usuario.setFotoPerfil(fotoPerfilString);
                            v_usuario.setCorreo(correoUser);
                            v_usuario.setNombre(nombreUsuario);

                            DatabaseReference reference = baseDatos.getReference("Usuarios/" + v_currentUser.getUid());
                            reference.setValue(v_usuario);
                        }
                    });

                }
            });

        }

    }


    @Override
    protected void onResume() {
        super.onResume();

        FirebaseUser currentUser = mAuth.getCurrentUser();

        if(currentUser != null){
            botonEnviar.setEnabled(false);
            DatabaseReference reference = baseDatos.getReference("Usuarios/" + currentUser.getUid());
            reference.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Usuario usuario = dataSnapshot.getValue(Usuario.class);
                    nombreUsuario = usuario.getNombre();
                    nombrePerfil.setText(nombreUsuario);
                    correoUser = usuario.getCorreo();
                    fotoPerfilString = usuario.getFotoPerfil();

                    if(!fotoPerfilString.isEmpty())
                        Glide.with(MainActivity.this).load(fotoPerfilString).into(fotoPerfil);

                    botonEnviar.setEnabled(true);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }

    }

    public static boolean verifyStoragePermissions(Activity activity) {
        String[] PERMISSIONS_STORAGE = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
        };
        int REQUEST_EXTERNAL_STORAGE = 1;
        int permission = ActivityCompat.checkSelfPermission(activity, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (permission != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    activity,
                    PERMISSIONS_STORAGE,
                    REQUEST_EXTERNAL_STORAGE
            );
            return false;
        }else{
            return true;
        }
    }


}
