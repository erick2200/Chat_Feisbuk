package com.erick.chat.entities;


import java.util.Map;

public class MensajeEnviar extends Mensaje {

    private Map hora;

    public MensajeEnviar() {
    }

    public MensajeEnviar(Map hora) {
        this.hora = hora;
    }

    public Map getHora() {
        return hora;
    }

    public void setHora(Map hora) {
        this.hora = hora;
    }

    public MensajeEnviar(String texto, String nombre, String fotoMensaje, String tipo, Map hora) {
        super(texto, nombre, fotoMensaje, tipo);
        this.hora = hora;
    }

    public MensajeEnviar(String texto, String urlFoto, String nombre, String fotoMensaje, String tipo, Map hora) {
        super(texto, urlFoto, nombre, fotoMensaje, tipo);
        this.hora = hora;
    }
}
