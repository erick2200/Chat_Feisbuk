package com.erick.chat.entities;


public class MensajeRecibir extends Mensaje {

    private Long hora ;

    public MensajeRecibir() {
    }

    public MensajeRecibir(Long hora) {
        this.hora = hora;
    }

    public MensajeRecibir(String texto, String nombre, String fotoMensaje, String tipo, Long hora) {
        super(texto, nombre, fotoMensaje, tipo);
        this.hora = hora;
    }

    public MensajeRecibir(String texto, String urlFoto, String nombre, String fotoMensaje, String tipo, Long hora) {
        super(texto, urlFoto, nombre, fotoMensaje, tipo);
        this.hora = hora;
    }

    public long getHora() {
        return hora;
    }

    public void setHora(Long hora) {
        this.hora = hora;
    }
}
