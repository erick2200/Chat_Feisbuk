package com.erick.chat;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import de.hdodenhof.circleimageview.CircleImageView;

public class HolderMensajes extends RecyclerView.ViewHolder {

    private CircleImageView fotoMensaje;
    private TextView textoMensaje;
    private TextView nombreMensaje;
    private TextView horaMensaje;

    private ImageView fotoDeMensaje;

    public HolderMensajes(@NonNull View itemView) {
        super(itemView);

        fotoMensaje = (CircleImageView) itemView.findViewById(R.id.fotoMensaje);
        nombreMensaje = (TextView) itemView.findViewById(R.id.nombreMensaje);
        textoMensaje = (TextView) itemView.findViewById(R.id.textoMensaje);
        horaMensaje = (TextView)itemView.findViewById(R.id.horaMensaje);
        fotoDeMensaje = (ImageView) itemView.findViewById(R.id.mensajeDeFoto);
    }

    public CircleImageView getFotoMensaje() {
        return fotoMensaje;
    }

    public void setFotoMensaje(CircleImageView fotoMensaje) {
        this.fotoMensaje = fotoMensaje;
    }

    public TextView getTextoMensaje() {
        return textoMensaje;
    }

    public ImageView getFotoDeMensaje() {
        return fotoDeMensaje;
    }

    public void setFotoDeMensaje(ImageView fotoDeMensaje) {
        this.fotoDeMensaje = fotoDeMensaje;
    }

    public void setTextoMensaje(TextView textoMensaje) {
        this.textoMensaje = textoMensaje;
    }

    public TextView getNombreMensaje() {
        return nombreMensaje;
    }

    public void setNombreMensaje(TextView nombreMensaje) {
        this.nombreMensaje = nombreMensaje;
    }

    public TextView getHoraMensaje() {
        return horaMensaje;
    }

    public void setHoraMensaje(TextView horaMensaje) {
        this.horaMensaje = horaMensaje;
    }
}
