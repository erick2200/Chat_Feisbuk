package com.erick.chat;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.erick.chat.entities.Mensaje;
import com.erick.chat.entities.MensajeRecibir;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AdapterMensajes extends RecyclerView.Adapter<HolderMensajes> {

    private List<MensajeRecibir> listaMensajes = new ArrayList<>();
    private Context c;

    public AdapterMensajes(Context c) {
        this.c = c;
    }

    public void addMensaje(MensajeRecibir mensaje)
    {
        listaMensajes.add(mensaje);
        notifyItemInserted(listaMensajes.size());
    }

    @NonNull
    @Override
    public HolderMensajes onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(c).inflate(R.layout.card_view_mensajes ,parent,false);
        return new HolderMensajes(v);
    }

    @Override
    public void onBindViewHolder(@NonNull HolderMensajes holder, int position) {
        holder.getNombreMensaje().setText(listaMensajes.get(position).getNombre());
        holder.getTextoMensaje().setText(listaMensajes.get(position).getTexto());
        holder.getTextoMensaje().setVisibility(View.VISIBLE);


        if(listaMensajes.get(position).getTipo().equals("2"))
        {
            holder.getFotoDeMensaje().setVisibility(View.VISIBLE);
            holder.getTextoMensaje().setVisibility(View.VISIBLE);

            Glide.with(c).load(listaMensajes.get(position).getUrlFoto()).into(holder.getFotoDeMensaje());

        }else if (listaMensajes.get(position).getTipo().equals("1"))
        {
            holder.getFotoDeMensaje().setVisibility(View.GONE);
            holder.getTextoMensaje().setVisibility(View.VISIBLE);
        }

        if(listaMensajes.get(position).getFotoMensaje().isEmpty())
        {
            holder.getFotoMensaje().setImageResource(R.mipmap.ic_launcher);
        }else
        {
            Glide.with(c).load(listaMensajes.get(position).getFotoMensaje()).into(holder.getFotoMensaje());
        }


        Long codigoHora =listaMensajes.get(position).getHora();
        Date d = new Date(codigoHora);
        SimpleDateFormat adf = new SimpleDateFormat("hh mm a");
        holder.getHoraMensaje().setText(adf.format(d));

    }

    @Override
    public int getItemCount() {
        return listaMensajes.size();
    }
}
